package com.hydra.aim

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private external fun nativeProfile(dpi: Int, sensitivity: Int): String
    private external fun nativeClamp(value: Int, minimum: Int, maximum: Int): Int

    companion object {
        init { System.loadLibrary("hydra_aim") }
        private const val BG = 0xFF09090D.toInt()
        private const val PANEL = 0xFF17171F.toInt()
        private const val RED = 0xFFFF303B.toInt()
        private const val WHITE = 0xFFF5F5F7.toInt()
        private const val MUTED = 0xFFAAAAB5.toInt()
    }

    private lateinit var dpiValue: TextView
    private lateinit var sensitivityValue: TextView
    private lateinit var result: TextView
    private var dpi = 480
    private var sensitivity = 90

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        updateProfile()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(BG)
        }
        val scroll = android.widget.ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        content.addView(text("HYDRA AIM", 30, RED, true))
        content.addView(text("ANDROID  /  AIM CONFIGURATION", 11, MUTED, true).withBottom(22))
        content.addView(section("CONFIGURAÇÕES"))
        dpiValue = text("DPI: $dpi", 16, WHITE, true)
        content.addView(dpiValue)
        content.addView(slider(100, 1000, dpi) { dpi = it; dpiValue.text = "DPI: $dpi" })
        sensitivityValue = text("Sensibilidade: $sensitivity", 16, WHITE, true).withTop(18)
        content.addView(sensitivityValue)
        content.addView(slider(0, 200, sensitivity) {
            sensitivity = it
            sensitivityValue.text = "Sensibilidade: $sensitivity"
        })
        content.addView(section("FERRAMENTAS").withTop(26))
        content.addView(actionButton("CALCULAR PERFIL") { updateProfile() })
        content.addView(actionButton("CENTRALIZAR MIRA DE TREINO") {
            result.text = "Mira de treino: centralizada. Abra o modo de prática abaixo."
        })
        content.addView(actionButton("ABRIR TREINAMENTO DE PRECISÃO") { showTrainer() })
        result = text("Ajuste os controles e calcule seu perfil.", 14, MUTED, false).withTop(18)
        content.addView(result)
        content.addView(text("Os perfis são recomendações para configuração manual. O app não controla nem altera o Free Fire.", 12, MUTED, false).withTop(26))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showTrainer() {
        val dialog = android.app.Dialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(PANEL)
        }
        val target = TextView(this).apply {
            text = "+\n\nTOQUE NO CENTRO DO ALVO\n\nPrecisão: modo de prática"
            gravity = Gravity.CENTER
            setTextColor(WHITE)
            textSize = 20f
            setPadding(10, 40, 10, 40)
        }
        var hits = 0
        target.setOnClickListener { hits++; target.text = "+\n\nACERTOS: $hits\n\nToque novamente para treinar" }
        box.addView(target)
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
    }

    private fun updateProfile() { result.text = nativeProfile(dpi, sensitivity) }

    private fun slider(min: Int, max: Int, initial: Int, changed: (Int) -> Unit): SeekBar = SeekBar(this).apply {
        this.max = max - min
        progress = nativeClamp(initial, min, max) - min
        progressTintList = android.content.res.ColorStateList.valueOf(RED)
        thumbTintList = android.content.res.ColorStateList.valueOf(RED)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { changed(value + min) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) { updateProfile() }
        })
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(WHITE)
        setBackgroundColor(PANEL)
        isAllCaps = false
        textSize = 14f
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = 10
        layoutParams = p
    }

    private fun section(value: String) = text(value, 12, RED, true).withBottom(12)
    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun TextView.withTop(px: Int): TextView = apply {
        val p = layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(-1, -2)
        p.topMargin = px; layoutParams = p
    }
    private fun TextView.withBottom(px: Int): TextView = apply {
        val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = px; layoutParams = p
    }
}