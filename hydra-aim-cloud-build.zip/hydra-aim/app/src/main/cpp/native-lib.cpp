#include <jni.h>
#include <algorithm>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_hydra_aim_MainActivity_nativeProfile(JNIEnv *env, jobject, jint dpi, jint sensitivity) {
    const int safeDpi = std::clamp(dpi, 100, 1000);
    const int safeSensitivity = std::clamp(sensitivity, 0, 200);
    const int recommended = std::clamp((safeSensitivity * 800) / std::max(safeDpi, 1), 1, 200);
    const std::string result = "Perfil calculado: " + std::to_string(recommended) +
        " | DPI " + std::to_string(safeDpi) +
        " | Sensibilidade " + std::to_string(safeSensitivity);
    return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_hydra_aim_MainActivity_nativeClamp(JNIEnv *, jobject, jint value, jint minimum, jint maximum) {
    return std::clamp(value, minimum, maximum);
}