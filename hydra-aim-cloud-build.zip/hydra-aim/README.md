# HYDRA AIM Android

Aplicativo Android com interface preta/vermelha, controles de DPI e sensibilidade, cálculo local de perfil em C++ via JNI e treino de precisão dentro do próprio aplicativo.

## Build

Requisitos: Android Studio, JDK 17, Android SDK 35, NDK 27.0.12077973 e CMake 3.22.1.

1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle e a instalação dos componentes do SDK solicitados.
3. Selecione `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar sem computador (pelo celular)

1. Crie uma conta em https://github.com/ e um repositório novo.
2. Envie os arquivos desta pasta para a raiz do repositório.
3. Abra a aba `Actions`, selecione `Build HYDRA AIM APK` e toque em `Run workflow` (ou aguarde o build iniciado ao enviar para a branch `main`).
4. Quando terminar com sucesso, abra a execução e baixe `hydra-aim-debug-apk` em `Artifacts`.
5. Extraia o ZIP baixado e instale `app-debug.apk` no Android.

O fluxo em `.github/workflows/build-apk.yml` instala JDK, Android SDK, NDK, CMake e Gradle na máquina de compilação em nuvem.

O aplicativo não lê memória, não injeta código e não controla o Free Fire. O treinamento acontece somente dentro do HYDRA AIM; os valores calculados são sugestões para ajuste manual.